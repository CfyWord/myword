<?php

namespace app\common\model;

use \think\Model;
class SpecModel extends Model
{
    protected $name = 'spec';
    //开启自动时间戳写入和修改
  
}
