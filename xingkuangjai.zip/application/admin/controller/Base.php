<?php
namespace app\admin\controller;

use \think\Controller;
class Base extends controller
{
    protected function _initialize()
    {
     
    } 
}
