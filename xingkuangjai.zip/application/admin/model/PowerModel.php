<?php

namespace app\admin\model;

use \think\Model;
class PowerModel extends Model
{
    protected $name = 'power';
}
