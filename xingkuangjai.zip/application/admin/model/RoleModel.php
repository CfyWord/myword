<?php

namespace app\admin\model;

use \think\Model;
class RoleModel extends Model
{
    protected $name = 'role';
}
