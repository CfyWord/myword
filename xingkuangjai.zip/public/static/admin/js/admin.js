layui.use('element', function(){
    var $ = layui.jquery
    ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
  
    //触发事件
    var active = {
	    tabAdd: function(){
	    	var othis = $(this), 
	    	type = othis.data('type'),
	    	url = othis.data('url'),
	    	title = othis.children('span').text(),
	    	content = '<iframe src="'+url+'"></iframe>';
	    	
      		//新增一个Tab项
        	element.tabAdd('demo', {
		        title: title 
		        ,content: content
		        ,id: url 
		    })
	    }
	    ,closeThisTabs: function(){  //关闭当前标签页

	    	var url = $('.layui-tab-title .layui-this').attr('lay-id');
	      	element.tabDelete('demo', url); 
	    }
	    ,closeOtherTabs: function(){  //关闭其它标签页

	    	var url = $('.layui-tab-title .layui-this').attr('lay-id');
	    	for (var tt = $('.layui-tab-title li').length - 1; tt >= 0; tt--) {

		        layid = $('.layui-tab-title li').eq(tt).attr('lay-id');

		        if(layid != url){

		          	element.tabDelete('demo', layid);
		        }
	      	}
	    }
	    ,closeAllTabs: function(){  //关闭全部标签页

	    	for (var tt = $('.layui-tab-title li').length - 1; tt >= 0; tt--) {

		        layid = $('.layui-tab-title li').eq(tt).attr('lay-id');
		        
		          	element.tabDelete('demo', layid);
		        
	      	}
	    }
	    ,refresh: function(){  //刷新当前标签页
	    	var url = $('.layui-tab-title .layui-this').attr('lay-id');
	    	$('.layui-tab-content .layui-show iframe ').attr("src",url).ready();
	    }
  	};

  	//内容区域高度
  	height=$(window).height();

  	$(".layui-tab-content").height(height-92);

  	$(window).resize(function () {
  		height=$(window).height();

  		$(".layui-tab-content").height(height-92);

  	})

	$('.site-demo-active').on('click', function(){
	    var othis = $(this), 
	    type = othis.data('type'),
	    url = othis.data('url');
	    to = 0;
	    for (var i = $('.layui-tab-title li').length - 1; i >= 0; i--) {
	      	layid=$('.layui-tab-title li').eq(i).attr('lay-id');
	      	if(layid == url){
	        	to = 1;
	      	}
	    }
	    if(to == 0){
	    	active[type] ? active[type].call(this, othis) : '';
		}
	    element.tabChange('demo', url);
	});

  	$('.wenx-click-admin').on('click', function(){
  		var othis = $(this),
  			type = othis.data('target');
  			active[type] ? active[type].call(this, othis) : '';
  	});

  	$('.wenx-side-fold').click(function(){

		if($(window).width()>992){

			if($('.layui-layout-body').hasClass('wenx-side-shrink')){

				$('.layui-layout-body').removeClass('wenx-side-shrink');
				$(this).children('a').children('i').attr('class','layui-icon layui-icon-shrink-right');

			}else{

				$('.layui-layout-body').addClass('wenx-side-shrink');
				$(this).children('a').children('i').attr('class','layui-icon layui-icon-spread-left');
			}

		}else{

			if($('.layui-layout-body').hasClass('wenx-side-spread-sm')){

				$('.layui-layout-body').removeClass('wenx-side-spread-sm');
				$(this).children('a').children('i').attr('class','layui-icon layui-icon-spread-left');

			}else{

				$('.layui-layout-body').addClass('wenx-side-spread-sm');
				$(this).children('a').children('i').attr('class','layui-icon layui-icon-shrink-right');
			}

		}
	})

	if($(window).width()<992){
		$('.wenx-side-fold').children('a').children('i').attr('class','layui-icon layui-icon-spread-left');
	}

	var length = 0;
	var num = 1;
	$('.layui-icon-prev').unbind('click').bind('click',function(){

	    length = length - num >= 0 ? length - num : 0;
	   	var left = $('.layui-tab-title li').eq(length).position().left;
	    $('.layui-tab-title').stop(true).animate({ left : -left },200);
	})

	$('.layui-icon-next').unbind('click').bind('click',function(){

		var liLeng  = $('.layui-tab-title li').length - 1;
		var boxWid  = $('.layui-tab-title').width() ;
	    var zliWid  = 0;
	    $('.layui-tab-title').children('span').remove().end().find('li').each(function(){

	        zliWid += $(this).outerWidth() ;
	    })

	    if(boxWid < zliWid && zliWid-boxWid > $('.layui-tab-title li').eq(length).position().left){

	    	length = length + num <= liLeng ? length + num : length;
			var left = $('.layui-tab-title li').eq(length).position().left;
			$('.layui-tab-title').stop(true).animate({ left : -left },200);
	    }
		
	});
	
	$('body').on("mouseover mouseout",'.td-brand-img',function () {
	
		// var top = $(this).offset().top;
		// var left = $(this).offset().left+$(this).width();
		// var $imgbox =' <div class="brand-img-flex-box" style="top:100%;right:0;width:auto;"><img src="'+$(this).attr('src')+'"/></div>';
		// if(event.type == "mouseover"){
		//   //鼠标悬浮
		  
		//   $(this).parent().css('position','relative').append($imgbox);
		// }else if(event.type == "mouseout"){
		//   //鼠标离开
		//   $(".brand-img-flex-box").remove();
		// }
		
	
			
	})
});