    /* 封装ajax函数
     * @param {string}opt.method http连接的方式，包括POST和GET两种方式
     * @param {string}opt.url 发送请求的url
     * @param {boolean}opt.async 是否为异步请求，true为异步的，false为同步的
     * @param {object}opt.data 发送的参数，格式为对象类型
     */
    function ajax(opt) {
        opt = opt || {};
        opt.method = opt.method.toUpperCase() || 'POST';
        opt.url = opt.url || '';
        opt.async = opt.async || true;
        opt.data = opt.data || null;
        opt.success = opt.success || function () {};
        opt.error = opt.error || function () {};
        opt.layerTime = opt.layerTime||2000;

        layer.load(1, {
          shade: [0.1,'#fff'] //0.1透明度的白色背景
        });
        var xmlHttp = null;
        if (XMLHttpRequest) {
            xmlHttp = new XMLHttpRequest();
        }
        else {
            xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
        }var params = [];
        for (var key in opt.data){
            params.push(key + '=' + opt.data[key]);
        }
        var postData = params.join('&');
        if (opt.method.toUpperCase() === 'POST') {
            xmlHttp.open(opt.method, opt.url, opt.async);
            xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
            xmlHttp.send(postData);
        }
        else if (opt.method.toUpperCase() === 'GET') {
            xmlHttp.open(opt.method, opt.url + '?' + postData, opt.async);
            xmlHttp.send(null);
        } 
        xmlHttp.onreadystatechange = function () {
            layer.closeAll();
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
               
                //返回数据执行，用到layui 的弹窗，要加载layui的js
                result = JSON.parse(xmlHttp.responseText);
                opt.success(result);
                layer.msg(result.msg, {time: opt.layerTime,icon: result.code},function(){
                    window.location.href = result.url;
                });
            }else{
                opt.error();
            }
        };
    }